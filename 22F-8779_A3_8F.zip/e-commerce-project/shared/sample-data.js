// ==========================================
// SAMPLE DATA INITIALIZATION
// ==========================================

/**
 * Initialize localStorage with sample products
 * Run this script once to populate demo data
 * Access it via console: initializeSampleData()
 */

function initializeSampleData() {
    const sampleProducts = [
        {
            id: 1709430000,
            name: "Wireless Bluetooth Headphones",
            price: 79.99,
            stock: 15,
            category: "Electronics",
            image: "./assets/placeholder.png"
        },
        {
            id: 1709430001,
            name: "Premium T-Shirt",
            price: 29.99,
            stock: 45,
            category: "Fashion",
            image: "./assets/placeholder.png"
        },
        {
            id: 1709430002,
            name: "Coffee Maker",
            price: 64.99,
            stock: 8,
            category: "Home & Garden",
            image: "./assets/placeholder.png"
        },
        {
            id: 1709430003,
            name: "Running Shoes",
            price: 119.99,
            stock: 22,
            category: "Sports",
            image: "./assets/placeholder.png"
        },
        {
            id: 1709430004,
            name: "JavaScript Programming Book",
            price: 34.99,
            stock: 30,
            category: "Books",
            image: "./assets/placeholder.png"
        },
        {
            id: 1709430005,
            name: "Portable Phone Charger",
            price: 24.99,
            stock: 0,
            category: "Electronics",
            image: "./assets/placeholder.png"
        },
        {
            id: 1709430006,
            name: "Yoga Mat",
            price: 39.99,
            stock: 18,
            category: "Sports",
            image: "./assets/placeholder.png"
        },
        {
            id: 1709430007,
            name: "Garden Tool Set",
            price: 49.99,
            stock: 12,
            category: "Home & Garden",
            image: "./assets/placeholder.png"
        },
        {
            id: 1709430008,
            name: "Designer Sunglasses",
            price: 149.99,
            stock: 7,
            category: "Fashion",
            image: "./assets/placeholder.png"
        },
        {
            id: 1709430009,
            name: "Smart Watch",
            price: 199.99,
            stock: 11,
            category: "Electronics",
            image: "./assets/placeholder.png"
        },
        {
            id: 1709430010,
            name: "Web Development Book",
            price: 39.99,
            stock: 25,
            category: "Books",
            image: "./assets/placeholder.png"
        },
        {
            id: 1709430011,
            name: "Desktop Lamp",
            price: 44.99,
            stock: 20,
            category: "Home & Garden",
            image: "./assets/placeholder.png"
        }
    ];

    try {
        localStorage.setItem('ecommerce_products', JSON.stringify(sampleProducts));
        console.log('✅ Sample data initialized successfully!');
        console.log(`📦 ${sampleProducts.length} products loaded`);
        console.log('🔄 Refresh the store page to see the products');
        
        // Also show products in console
        console.table(sampleProducts);
        
        return true;
    } catch (error) {
        console.error('❌ Error initializing sample data:', error);
        return false;
    }
}

/**
 * Clear all data from localStorage
 */
function clearAllData() {
    if (confirm('Are you sure? This will delete all products and cart data.')) {
        localStorage.removeItem('ecommerce_products');
        localStorage.removeItem('ecommerce_cart');
        console.log('✅ All data cleared');
        console.log('🔄 Refresh the page');
        return true;
    }
    return false;
}

/**
 * View all products in localStorage
 */
function viewAllProducts() {
    const products = JSON.parse(localStorage.getItem('ecommerce_products') || '[]');
    console.log('📦 All Products:');
    console.table(products);
    return products;
}

/**
 * View shopping cart
 */
function viewCart() {
    const cart = JSON.parse(localStorage.getItem('ecommerce_cart') || '[]');
    console.log('🛒 Shopping Cart:');
    console.table(cart);
    return cart;
}

/**
 * Get summary statistics
 */
function getStats() {
    const products = JSON.parse(localStorage.getItem('ecommerce_products') || '[]');
    const cart = JSON.parse(localStorage.getItem('ecommerce_cart') || '[]');

    const stats = {
        totalProducts: products.length,
        totalValue: products.reduce((sum, p) => sum + (p.price * p.stock), 0),
        totalStock: products.reduce((sum, p) => sum + p.stock, 0),
        outOfStock: products.filter(p => p.stock === 0).length,
        categories: [...new Set(products.map(p => p.category))],
        cartItems: cart.length,
        cartTotal: cart.reduce((sum, item) => sum + (item.price * item.quantity), 0),
        cartQuantity: cart.reduce((sum, item) => sum + item.quantity, 0)
    };

    console.log('📊 Store Statistics:');
    console.table(stats);
    return stats;
}

/**
 * Export data as JSON
 */
function exportData() {
    const data = {
        products: JSON.parse(localStorage.getItem('ecommerce_products') || '[]'),
        cart: JSON.parse(localStorage.getItem('ecommerce_cart') || '[]'),
        exportDate: new Date().toISOString()
    };

    console.log('📥 Exported Data:');
    console.log(JSON.stringify(data, null, 2));
    
    // Copy to clipboard
    const jsonString = JSON.stringify(data, null, 2);
    navigator.clipboard.writeText(jsonString).then(() => {
        console.log('✅ Data copied to clipboard!');
    });

    return data;
}

/**
 * Find product by ID
 */
function findProduct(productId) {
    const products = JSON.parse(localStorage.getItem('ecommerce_products') || '[]');
    const product = products.find(p => p.id === productId);
    
    if (product) {
        console.log('✅ Found product:');
        console.table([product]);
    } else {
        console.log('❌ Product not found');
    }
    
    return product;
}

/**
 * Find products by category
 */
function findByCategory(category) {
    const products = JSON.parse(localStorage.getItem('ecommerce_products') || '[]');
    const found = products.filter(p => p.category === category);
    
    console.log(`✅ Found ${found.length} products in "${category}":"`);
    console.table(found);
    
    return found;
}

// Auto-run on first load (comment out if you don't want auto-initialization)
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        // Only initialize if no products exist
        if (!localStorage.getItem('ecommerce_products')) {
            console.log('🚀 Initializing demo data...');
            initializeSampleData();
        }
    });
}

// Print available commands
console.log(`
╔════════════════════════════════════════════════════════════╗
║           E-Commerce Console Commands                      ║
╚════════════════════════════════════════════════════════════╝

📦 PRODUCTS:
  initializeSampleData()  - Load 12 demo products
  viewAllProducts()       - Show all products
  findProduct(id)         - Find product by ID
  findByCategory(cat)     - Find products by category

🛒 CART:
  viewCart()             - Show shopping cart items

📊 STATS:
  getStats()             - Get store statistics

📥 DATA:
  exportData()           - Export all data as JSON
  clearAllData()         - Delete all products and cart

Try running: initializeSampleData()
`);