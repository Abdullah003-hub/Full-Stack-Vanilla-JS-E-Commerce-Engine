// ==========================================
// SHARED UTILITIES & HELPER FUNCTIONS
// ==========================================

/**
 * Storage Utility - Centralized localStorage management
 */
const StorageUtil = {
    /**
     * Get item from localStorage
     * @param {string} key - Storage key
     * @returns {any|null} - Parsed item or null
     */
    getItem(key) {
        try {
            const item = localStorage.getItem(key);
            return item ? JSON.parse(item) : null;
        } catch (error) {
            console.error(`Error retrieving item from storage (${key}):`, error);
            return null;
        }
    },

    /**
     * Set item in localStorage
     * @param {string} key - Storage key
     * @param {any} value - Value to store
     * @returns {boolean} - Success status
     */
    setItem(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
            return true;
        } catch (error) {
            console.error(`Error saving item to storage (${key}):`, error);
            return false;
        }
    },

    /**
     * Remove item from localStorage
     * @param {string} key - Storage key
     * @returns {boolean} - Success status
     */
    removeItem(key) {
        try {
            localStorage.removeItem(key);
            return true;
        } catch (error) {
            console.error(`Error removing item from storage (${key}):`, error);
            return false;
        }
    },

    /**
     * Clear all localStorage
     * @returns {boolean} - Success status
     */
    clear() {
        try {
            localStorage.clear();
            return true;
        } catch (error) {
            console.error('Error clearing storage:', error);
            return false;
        }
    }
};

/**
 * Validation Utility - Input validation helpers
 */
const ValidationUtil = {
    /**
     * Validate email
     * @param {string} email - Email to validate
     * @returns {boolean}
     */
    isValidEmail(email) {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    },

    /**
     * Validate URL
     * @param {string} url - URL to validate
     * @returns {boolean}
     */
    isValidURL(url) {
        try {
            new URL(url);
            return true;
        } catch (_) {
            return false;
        }
    },

    /**
     * Validate positive number
     * @param {number} value - Value to validate
     * @returns {boolean}
     */
    isPositiveNumber(value) {
        return !isNaN(value) && value > 0;
    },

    /**
     * Validate non-empty string
     * @param {string} value - String to validate
     * @returns {boolean}
     */
    isNonEmptyString(value) {
        return typeof value === 'string' && value.trim().length > 0;
    }
};

/**
 * Format Utility - Number and string formatting
 */
const FormatUtil = {
    /**
     * Format number as currency
     * @param {number} value - Value to format
     * @param {string} currency - Currency symbol (default: $)
     * @returns {string}
     */
    currency(value, currency = '$') {
        return `${currency}${parseFloat(value).toFixed(2)}`;
    },

    /**
     * Format number with thousands separator
     * @param {number} value - Value to format
     * @returns {string}
     */
    thousands(value) {
        return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    },

    /**
     * Escape HTML special characters
     * @param {string} text - Text to escape
     * @returns {string}
     */
    escapeHTML(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    },

    /**
     * Capitalize first letter of string
     * @param {string} text - Text to capitalize
     * @returns {string}
     */
    capitalize(text) {
        return text.charAt(0).toUpperCase() + text.slice(1).toLowerCase();
    },

    /**
     * Truncate string to max length
     * @param {string} text - Text to truncate
     * @param {number} maxLength - Maximum length
     * @returns {string}
     */
    truncate(text, maxLength) {
        return text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
    }
};

/**
 * DOM Utility - Common DOM operations
 */
const DOMUtil = {
    /**
     * Create element with attributes
     * @param {string} tag - HTML tag
     * @param {object} attributes - Element attributes
     * @returns {HTMLElement}
     */
    createElement(tag, attributes = {}) {
        const element = document.createElement(tag);
        Object.entries(attributes).forEach(([key, value]) => {
            if (key === 'class') {
                element.className = value;
            } else if (key === 'style') {
                Object.assign(element.style, value);
            } else {
                element.setAttribute(key, value);
            }
        });
        return element;
    },

    /**
     * Add event listener with cleanup
     * @param {HTMLElement} element - Target element
     * @param {string} event - Event name
     * @param {function} handler - Event handler
     * @returns {function} - Unsubscribe function
     */
    on(element, event, handler) {
        element.addEventListener(event, handler);
        return () => element.removeEventListener(event, handler);
    },

    /**
     * Remove element
     * @param {HTMLElement} element - Element to remove
     */
    remove(element) {
        element?.remove();
    },

    /**
     * Toggle class
     * @param {HTMLElement} element - Target element
     * @param {string} className - Class name
     */
    toggleClass(element, className) {
        element?.classList.toggle(className);
    },

    /**
     * Hide element
     * @param {HTMLElement} element - Target element
     */
    hide(element) {
        if (element) element.style.display = 'none';
    },

    /**
     * Show element
     * @param {HTMLElement} element - Target element
     */
    show(element) {
        if (element) element.style.display = '';
    }
};

/**
 * Analytics Utility - Track user actions (optional)
 */
const AnalyticsUtil = {
    /**
     * Track event
     * @param {string} eventName - Event name
     * @param {object} data - Event data
     */
    trackEvent(eventName, data = {}) {
        console.log(`[Analytics] Event: ${eventName}`, data);
        // Can be extended to integrate with actual analytics service
    },

    /**
     * Track page view
     * @param {string} page - Page name
     */
    trackPageView(page) {
        this.trackEvent('page_view', { page });
    },

    /**
     * Track product view
     * @param {string} productId - Product ID
     * @param {string} productName - Product name
     */
    trackProductView(productId, productName) {
        this.trackEvent('product_view', { productId, productName });
    },

    /**
     * Track add to cart
     * @param {string} productId - Product ID
     * @param {number} quantity - Quantity
     * @param {number} price - Product price
     */
    trackAddToCart(productId, quantity, price) {
        this.trackEvent('add_to_cart', { productId, quantity, price });
    },

    /**
     * Track checkout
     * @param {number} total - Order total
     * @param {number} itemCount - Number of items
     */
    trackCheckout(total, itemCount) {
        this.trackEvent('checkout', { total, itemCount });
    }
};

// Export utilities (for module use if needed)
if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
        StorageUtil,
        ValidationUtil,
        FormatUtil,
        DOMUtil,
        AnalyticsUtil
    };
}