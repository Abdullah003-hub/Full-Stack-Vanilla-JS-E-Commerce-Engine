// ==========================================
// STOREFRONT - SHOPPING & CART MANAGEMENT
// ==========================================

class StorefrontManager {
    constructor() {
        this.STORAGE_KEY = 'ecommerce_products';
        this.CART_KEY = 'ecommerce_cart';
        this.initializeElements();
        this.attachEventListeners();
        this.loadProducts();
        this.loadCart();
    }

    // Initialize DOM elements
    initializeElements() {
        this.productsGrid = document.getElementById('productsGrid');
        this.cartSidebar = document.getElementById('cartSidebar');
        this.cartOverlay = document.getElementById('cartOverlay');
        this.cartToggle = document.getElementById('cartToggle');
        this.closeCart = document.getElementById('closeCart');
        this.cartItemsList = document.getElementById('cartItemsList');
        this.cartCount = document.querySelector('.cart-count');
        this.subtotal = document.getElementById('subtotal');
        this.tax = document.getElementById('tax');
        this.total = document.getElementById('total');
        this.checkoutBtn = document.getElementById('checkoutBtn');
        this.clearCartBtn = document.getElementById('clearCartBtn');
        this.searchInput = document.getElementById('searchInput');
        this.categoryFilter = document.getElementById('categoryFilter');

        this.allProducts = [];
        this.cart = [];
    }

    // Attach event listeners
    attachEventListeners() {
        this.cartToggle.addEventListener('click', () => this.toggleCart());
        this.closeCart.addEventListener('click', () => this.toggleCart());
        this.cartOverlay.addEventListener('click', () => this.toggleCart());
        this.checkoutBtn.addEventListener('click', () => this.checkout());
        this.clearCartBtn.addEventListener('click', () => this.clearCart());
        this.searchInput.addEventListener('input', () => this.filterProducts());
        this.categoryFilter.addEventListener('change', () => this.filterProducts());
    }

    // Load all products from localStorage
    loadProducts() {
        const stored = localStorage.getItem(this.STORAGE_KEY);
        this.allProducts = stored ? JSON.parse(stored) : [];
        
        // If no products exist, initialize sample data
        if (this.allProducts.length === 0) {
            if (typeof initializeSampleData === 'function') {
                initializeSampleData();
                // Reload after initialization
                const newStored = localStorage.getItem(this.STORAGE_KEY);
                this.allProducts = newStored ? JSON.parse(newStored) : [];
            }
        }
        
        this.displayProducts(this.allProducts);
    }

    // Load cart from localStorage
    loadCart() {
        const stored = localStorage.getItem(this.CART_KEY);
        this.cart = stored ? JSON.parse(stored) : [];
        this.updateCartUI();
    }

    // Display products in grid
    displayProducts(productsToDisplay) {
        if (productsToDisplay.length === 0) {
            this.productsGrid.innerHTML = `
                <div class="loading-state" style="grid-column: 1 / -1;">
                    <p>No products available. Please add products in the admin panel.</p>
                </div>
            `;
            return;
        }

        this.productsGrid.innerHTML = productsToDisplay.map(product => {
            const isOutOfStock = product.stock <= 0;
            const isLowStock = product.stock > 0 && product.stock <= 10;
            
            return `
                <div class="product-card">
                    <div class="product-image-container">
                        <img 
                            src="${this.escapeHTML(product.image)}" 
                            alt="${this.escapeHTML(product.name)}"
                            class="product-image"
                            onerror="this.src='https://via.placeholder.com/280x250?text=No+Image'"
                        >
                        <span class="product-badge ${isOutOfStock ? 'out-of-stock' : ''}">
                            ${isOutOfStock ? 'Out of Stock' : 'In Stock'}
                        </span>
                    </div>

                    <div class="product-info">
                        <span class="product-category">${this.escapeHTML(product.category)}</span>
                        <h3 class="product-name">${this.escapeHTML(product.name)}</h3>
                        <div class="product-price">$${product.price.toFixed(2)}</div>
                        
                        <div class="product-stock">
                            <span class="stock-status ${isLowStock ? 'low-stock' : isOutOfStock ? 'out-of-stock' : ''}">
                                ${isOutOfStock ? 'Out of Stock' : isLowStock ? `Only ${product.stock} left` : `${product.stock} in stock`}
                            </span>
                        </div>

                        <div class="product-actions">
                            <button 
                                class="btn btn-add-to-cart"
                                onclick="storefrontManager.addToCart(${product.id})"
                                ${isOutOfStock ? 'disabled' : ''}
                            >
                                ${isOutOfStock ? 'Out of Stock' : 'Add to Cart'}
                            </button>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    }

    // Filter products based on search and category
    filterProducts() {
        const searchTerm = this.searchInput.value.toLowerCase();
        const selectedCategory = this.categoryFilter.value;

        const filtered = this.allProducts.filter(product => {
            const matchesSearch = product.name.toLowerCase().includes(searchTerm);
            const matchesCategory = !selectedCategory || product.category === selectedCategory;
            return matchesSearch && matchesCategory;
        });

        this.displayProducts(filtered);
    }

    // Add product to cart
    addToCart(productId) {
        const product = this.allProducts.find(p => p.id === productId);
        
        if (!product || product.stock <= 0) {
            this.showNotification('This product is out of stock!', 'error');
            return;
        }

        // Check if product already in cart
        const existingCartItem = this.cart.find(item => item.id === productId);

        if (existingCartItem) {
            existingCartItem.quantity += 1;
        } else {
            this.cart.push({
                id: product.id,
                name: product.name,
                price: product.price,
                image: product.image,
                quantity: 1
            });
        }

        // Decrease product stock
        product.stock -= 1;
        
        // Update localStorage
        this.saveCart();
        this.saveProducts();
        this.loadProducts(); // Refresh product display
        
        this.showNotification(`${product.name} added to cart!`, 'success');
    }

    // Remove product from cart
    removeFromCart(productId) {
        const product = this.allProducts.find(p => p.id === productId);
        const cartItem = this.cart.find(item => item.id === productId);

        if (cartItem && product) {
            // Return the quantity back to stock
            product.stock += cartItem.quantity;
            this.saveProducts();
        }

        this.cart = this.cart.filter(item => item.id !== productId);
        this.saveCart();
        this.loadProducts();
        this.updateCartUI();
        this.showNotification('Product removed from cart', 'info');
    }

    // Update item quantity in cart
    updateCartItemQuantity(productId, newQuantity) {
        const cartItem = this.cart.find(item => item.id === productId);
        const product = this.allProducts.find(p => p.id === productId);

        if (!cartItem || !product) return;

        const quantityDifference = newQuantity - cartItem.quantity;

        if (quantityDifference > 0) {
            // Increasing quantity - check if stock available
            if (product.stock < quantityDifference) {
                this.showNotification(`Only ${product.stock} items available!`, 'error');
                return;
            }
            product.stock -= quantityDifference;
        } else if (quantityDifference < 0) {
            // Decreasing quantity - return to stock
            product.stock += Math.abs(quantityDifference);
        }

        if (newQuantity <= 0) {
            this.removeFromCart(productId);
        } else {
            cartItem.quantity = newQuantity;
            this.saveCart();
            this.saveProducts();
            this.loadProducts();
            this.updateCartUI();
        }
    }

    // Update cart UI
    updateCartUI() {
        const cartItemCount = this.cart.reduce((sum, item) => sum + item.quantity, 0);
        this.cartCount.textContent = cartItemCount;

        if (this.cart.length === 0) {
            this.cartItemsList.innerHTML = '<p class="empty-cart">Your cart is empty</p>';
            this.checkoutBtn.disabled = true;
            this.subtotal.textContent = '$0.00';
            this.tax.textContent = '$0.00';
            this.total.textContent = '$0.00';
            return;
        }

        this.checkoutBtn.disabled = false;

        this.cartItemsList.innerHTML = this.cart.map(item => `
            <div class="cart-item">
                <img 
                    src="${this.escapeHTML(item.image)}" 
                    alt="${this.escapeHTML(item.name)}"
                    class="cart-item-image"
                    onerror="this.src='https://via.placeholder.com/80?text=No+Image'"
                >
                <div class="cart-item-details">
                    <div class="cart-item-name">${this.escapeHTML(item.name)}</div>
                    <div class="cart-item-price">$${item.price.toFixed(2)}</div>
                    <div class="cart-item-quantity">
                        <button class="quantity-btn" onclick="storefrontManager.updateCartItemQuantity(${item.id}, ${item.quantity - 1})">−</button>
                        <span>${item.quantity}</span>
                        <button class="quantity-btn" onclick="storefrontManager.updateCartItemQuantity(${item.id}, ${item.quantity + 1})">+</button>
                    </div>
                </div>
                <button class="remove-btn" onclick="storefrontManager.removeFromCart(${item.id})">×</button>
            </div>
        `).join('');

        this.updateSummary();
    }

    // Update cart summary
    updateSummary() {
        const subtotalAmount = this.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const taxAmount = subtotalAmount * 0.1;
        const totalAmount = subtotalAmount + taxAmount;

        this.subtotal.textContent = `$${subtotalAmount.toFixed(2)}`;
        this.tax.textContent = `$${taxAmount.toFixed(2)}`;
        this.total.textContent = `$${totalAmount.toFixed(2)}`;
    }

    // Checkout
    checkout() {
        if (this.cart.length === 0) {
            this.showNotification('Your cart is empty!', 'error');
            return;
        }

        const cartSummary = this.cart.map(item => 
            `${item.quantity}x ${item.name} ($${(item.price * item.quantity).toFixed(2)})`
        ).join('\n');

        const subtotal = this.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const tax = subtotal * 0.1;
        const total = subtotal + tax;

        const confirmMessage = `
Order Summary:
${cartSummary}

Subtotal: $${subtotal.toFixed(2)}
Tax (10%): $${tax.toFixed(2)}
Total: $${total.toFixed(2)}

Proceed with checkout?`;

        if (confirm(confirmMessage)) {
            this.clearCart();
            this.showNotification('✅ Order placed successfully! Thank you for shopping.', 'success');
        }
    }

    // Clear cart
    clearCart() {
        this.cart = [];
        this.saveCart();
        localStorage.removeItem(this.CART_KEY);
        this.updateCartUI();
        this.loadProducts();
        this.toggleCart();
        this.showNotification('Cart cleared', 'info');
    }

    // Save cart to localStorage
    saveCart() {
        localStorage.setItem(this.CART_KEY, JSON.stringify(this.cart));
    }

    // Save products to localStorage
    saveProducts() {
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.allProducts));
    }

    // Toggle cart sidebar
    toggleCart() {
        this.cartSidebar.classList.toggle('active');
        this.cartOverlay.classList.toggle('active');
    }

    // Show notification
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        const bgColor = type === 'success' ? '#27ae60' : type === 'error' ? '#e74c3c' : '#3498db';
        
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: ${bgColor};
            color: white;
            padding: 15px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            font-weight: 600;
            z-index: 1001;
            max-width: 400px;
            animation: slideIn 0.3s ease;
        `;
        notification.textContent = message;
        document.body.appendChild(notification);

        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }

    // Escape HTML special characters
    escapeHTML(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Initialize the storefront manager when DOM is ready
let storefrontManager;
document.addEventListener('DOMContentLoaded', () => {
    storefrontManager = new StorefrontManager();
});