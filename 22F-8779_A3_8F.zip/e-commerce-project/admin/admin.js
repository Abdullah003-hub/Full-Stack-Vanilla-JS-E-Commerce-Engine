// ==========================================
// ADMIN DASHBOARD - INVENTORY MANAGEMENT
// ==========================================

class InventoryManager {
    constructor() {
        this.STORAGE_KEY = 'ecommerce_products';
        this.initializeElements();
        this.attachEventListeners();
        this.loadAndDisplayProducts();
    }

    // Initialize DOM elements
    initializeElements() {
        this.form = document.getElementById('productForm');
        this.nameInput = document.getElementById('productName');
        this.priceInput = document.getElementById('productPrice');
        this.stockInput = document.getElementById('productStock');
        this.categoryInput = document.getElementById('productCategory');
        this.imageInput = document.getElementById('productImage');
        this.tableBody = document.getElementById('productTableBody');
        this.productCount = document.getElementById('productCount');
    }

    // Attach event listeners
    attachEventListeners() {
        this.form.addEventListener('submit', (e) => this.handleFormSubmit(e));
    }

    // Validation Logic
    validateForm() {
        let isValid = true;
        this.clearErrors();

        // Validate Product Name
        if (!this.nameInput.value.trim()) {
            this.showError('nameError', 'Product name is required');
            isValid = false;
        }

        // Validate Price
        const price = parseFloat(this.priceInput.value);
        if (!this.priceInput.value || price <= 0) {
            this.showError('priceError', 'Price must be greater than 0');
            isValid = false;
        }

        // Validate Stock
        const stock = parseInt(this.stockInput.value);
        if (!this.stockInput.value || stock <= 0) {
            this.showError('stockError', 'Stock must be at least 1');
            isValid = false;
        }

        // Validate Category
        if (!this.categoryInput.value) {
            this.showError('categoryError', 'Please select a category');
            isValid = false;
        }

        // Validate Image URL
        if (!this.imageInput.value.trim()) {
            this.showError('imageError', 'Image URL is required');
            isValid = false;
        } else if (!this.isValidURL(this.imageInput.value)) {
            this.showError('imageError', 'Please enter a valid URL');
            isValid = false;
        }

        return isValid;
    }

    // Check if URL is valid
    isValidURL(string) {
        try {
            new URL(string);
            return true;
        } catch (_) {
            return false;
        }
    }

    // Show error message
    showError(elementId, message) {
        const errorElement = document.getElementById(elementId);
        errorElement.textContent = message;
        errorElement.classList.add('show');
    }

    // Clear all error messages
    clearErrors() {
        const errorElements = document.querySelectorAll('.error-msg');
        errorElements.forEach(el => {
            el.textContent = '';
            el.classList.remove('show');
        });
    }

    // Handle form submission
    handleFormSubmit(e) {
        e.preventDefault();

        if (!this.validateForm()) {
            return;
        }

        const newProduct = {
            id: Date.now(),
            name: this.nameInput.value.trim(),
            price: parseFloat(this.priceInput.value),
            stock: parseInt(this.stockInput.value),
            category: this.categoryInput.value,
            image: this.imageInput.value.trim()
        };

        this.addProductToStorage(newProduct);
        this.form.reset();
        this.clearErrors();
        this.loadAndDisplayProducts();
        this.showSuccessMessage('Product added successfully!');
    }

    // Add product to localStorage
    addProductToStorage(product) {
        const products = this.getAllProducts();
        products.push(product);
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(products));
    }

    // Get all products from localStorage
    getAllProducts() {
        const stored = localStorage.getItem(this.STORAGE_KEY);
        return stored ? JSON.parse(stored) : [];
    }

    // Delete product from localStorage
    deleteProduct(productId) {
        if (confirm('Are you sure you want to delete this product?')) {
            let products = this.getAllProducts();
            products = products.filter(p => p.id !== productId);
            localStorage.setItem(this.STORAGE_KEY, JSON.stringify(products));
            this.loadAndDisplayProducts();
            this.showSuccessMessage('Product deleted successfully!');
        }
    }

    // Load and display products in table
    loadAndDisplayProducts() {
        let products = this.getAllProducts();
        
        // If no products exist, initialize sample data
        if (products.length === 0) {
            if (typeof initializeSampleData === 'function') {
                initializeSampleData();
                // Reload after initialization
                products = this.getAllProducts();
            }
        }
        
        this.productCount.textContent = products.length;

        if (products.length === 0) {
            this.tableBody.innerHTML = `
                <tr class="empty-state">
                    <td colspan="6">No products yet. Add your first product above!</td>
                </tr>
            `;
            return;
        }

        this.tableBody.innerHTML = products.map(product => `
            <tr>
                <td>
                    <strong>${this.escapeHTML(product.name)}</strong>
                </td>
                <td>
                    <span class="badge">${this.escapeHTML(product.category)}</span>
                </td>
                <td>
                    <strong>$${product.price.toFixed(2)}</strong>
                </td>
                <td>
                    <span class="stock-badge ${product.stock <= 10 ? 'low-stock' : ''}">
                        ${product.stock} units
                    </span>
                </td>
                <td>
                    <img src="${this.escapeHTML(product.image)}" alt="${this.escapeHTML(product.name)}" onerror="this.src='https://via.placeholder.com/80?text=No+Image'">
                </td>
                <td>
                    <div class="action-buttons">
                        <button class="btn-delete" onclick="inventoryManager.deleteProduct(${product.id})">
                            🗑️ Delete
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    // Escape HTML special characters
    escapeHTML(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Show success message
    showSuccessMessage(message) {
        // Create a temporary alert-like message
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: #27ae60;
            color: white;
            padding: 15px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            font-weight: 600;
            z-index: 1000;
            animation: slideIn 0.3s ease;
        `;
        notification.textContent = message;
        document.body.appendChild(notification);

        setTimeout(() => {
            notification.style.animation = 'slideOut 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }
}

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }

    .badge {
        display: inline-block;
        background: #667eea;
        color: white;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.85em;
        font-weight: 600;
    }

    .stock-badge {
        display: inline-block;
        padding: 6px 12px;
        border-radius: 6px;
        background: #d4edda;
        color: #155724;
        font-weight: 600;
        font-size: 0.9em;
    }

    .stock-badge.low-stock {
        background: #fff3cd;
        color: #856404;
    }
`;
document.head.appendChild(style);

// Initialize the inventory manager when DOM is ready
let inventoryManager;
document.addEventListener('DOMContentLoaded', () => {
    inventoryManager = new InventoryManager();
});